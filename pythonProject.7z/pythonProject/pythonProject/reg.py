import re
from connect import connection

def user_authentication(login, password):
    with connection.cursor() as cursor:
        user_authentication_query = f"SELECT email, login, password FROM Student  " \
                                    f"WHERE (email = '{login}' AND password = '{password}') " \
                                    f"OR login = '{login}' AND password = '{password}'"
        cursor.execute(user_authentication_query)
        user_authentication_result = cursor.fetchall()
        return user_authentication_result

def user_registration(first_name, last_name, email, birth_certificate, login, password):
    with connection.cursor() as cursor:
        user_registration_query = f"INSERT INTO Student(first_name, last_name, email, phone, login, password, passport)" \
                                  f"VALUES ('{first_name}', '{last_name}', '{email}', '{birth_certificate}', '{login}', PASSWORD('{password}')"
        cursor.execute(user_registration_query)
        connection.commit()

# Пример использования функций

login = input("Введите логин/email: ")
password = input("Введите пароль: ")

auth_result = user_authentication(login, password)
if auth_result:
    print("Вход выполнен успешно! ")
else:
    print("Неверный логин или пароль ")

first_name = input("Введите имя: ")
last_name = input("Введите фамилию: ")
email = input("Введите email: ")
birth_certificate = input("Введите свидетельство о рождении: ")
login = input("Введите логин: ")
password = input("Введите пароль: ")

user_registration(first_name, last_name, email, birth_certificate, login, password)
print("Регистрация выполнена успешно! ")
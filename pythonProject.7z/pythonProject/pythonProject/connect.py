import pymysql
from config import host, user, password, bd_name



try:
    connection =pymysql.connect (
        host=host,
        port=3306,
        user=user,
        password= password,
        database= bd_name,
        cursorclass=pymysql.cursors.DictCursor
    )
    print('Successfully connect...')
    print("#" * 20)


except Exception as ex:
    print('Connection refused ...')
    print(ex)

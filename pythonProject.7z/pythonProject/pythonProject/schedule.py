import mysql.connector
from flask import Flask, request, render_template

# Подключение к базе данных
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="school"
)

app = Flask(__name__)


# Функция для получения списка учеников
def get_all_students():
    with connection.cursor() as cursor:
        select_all_query = "SELECT * FROM Student"
        cursor.execute(select_all_query)
        students = cursor.fetchall()
        return students


# Функция для обработки GET-запроса формы расписания
@app.route('/schedule/<int:student_id>', methods=['GET'])
def display_schedule_form(student_id):
    student = get_student(student_id)
    if student:
        return render_template('schedule_form.html', student=student)
    else:
        return "Ученик с ID {} не найден".format(student_id)


# Функция для получения информации об ученике
def get_student(student_id):
    with connection.cursor() as cursor:
        select_query = "SELECT * FROM Student WHERE ID = %s"
        cursor.execute(select_query, (student_id,))
        student = cursor.fetchone()
        return student


# Функция для обработки POST-запроса формы расписания
@app.route('/schedule/<int:student_id>', methods=['POST'])
def save_schedule(student_id):
    days = request.form.getlist('day')
    shifts = request.form.getlist('shift')

    # Здесь можно добавить логику для сохранения выбранного расписания в базе данных

    return "Расписание для ученика с ID {} успешно сохранено".format(student_id)


# Главная страница - список учеников
@app.route('/')
def student_list():
    students = get_all_students()
    return render_template('student_list.html', students=students)


if __name__ == '__main__':
    app.run()

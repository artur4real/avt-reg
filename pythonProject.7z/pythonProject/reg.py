import re
from connect import connection

def user_authentication(login, password):
    with connection.cursor() as cursor:
        user_authentication_query = f"SELECT email, login, password FROM Student " \
                                    f"WHERE (email = '{login}' AND password = '{password}') " \
                                    f"OR login = '{login}' AND password = '{password}'"
        cursor.execute(user_authentication_query)
        user_authentication_result = cursor.fetchall()
        return user_authentication_result


# Пример использования функции

login = input("Введите логин или email: ")
password = input("Введите пароль: ")

auth_result = user_authentication(login, password)
if auth_result:
    print("Вход выполнен успешно!")
else:
    print("Неверный логин или пароль")
